# Instruções Personalizadas do Projeto

Este arquivo contém as preferências de estilo, estrutura e comportamento para o desenvolvimento deste aplicativo. O Gemini (eu) consultará este arquivo em cada turno para garantir que as alterações estejam alinhadas com a sua visão.

## 🎨 Estilo Visual
- **Paleta de Cores:** (Ex: Tons de azul ardósia e esmeralda)
- **Tipografia:** (Ex: Inter para interface, JetBrains Mono para dados)
- **Bordas:** (Ex: rounded-2xl para todos os cards)
- **Sombra:** (Ex: shadow-md sutil)

## 🏗️ Estrutura e Arquitetura
- **Componentes:** (Ex: Preferir componentes pequenos e reutilizáveis em /src/components)
- **Estado:** (Ex: Usar Context API para estados globais)
- **Estilização:** (Ex: Usar exclusivamente Tailwind CSS)

## ⚙️ Preferências de Comportamento
- **Animações:** (Ex: Usar Framer Motion para transições de página)
- **Feedback:** (Ex: Sempre mostrar estados de carregamento (loading) em ações assíncronas)
- **Acessibilidade:** (Ex: Garantir contraste alto e labels em todos os inputs)

---
*Por favor, edite este arquivo ou me diga quais instruções você gostaria de adicionar aqui.*
