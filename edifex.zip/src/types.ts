/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ProjectStatus = 'planejamento' | 'em_andamento' | 'concluida' | 'atrasada';

export interface Project {
  id: string;
  name: string;
  client: string;
  location: string;
  budget: number;
  startDate: string;
  endDate: string;
  progress: number;
  status: ProjectStatus;
  ownerId: string;
  createdAt: string;
}

export interface Stage {
  id: string;
  projectId: string;
  name: string;
  responsible: string;
  startDate: string;
  endDate: string;
  progress: number;
  materials: string[];
  estimatedCost: number;
  actualCost: number;
}

export interface DailyLog {
  id: string;
  projectId: string;
  date: string;
  activities: string;
  problems: string;
  weather: 'ensolarado' | 'nublado' | 'chuva' | 'tempestade';
  decisions: string;
  observations: string;
  photos: string[];
  authorId: string;
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  dailyRate: number;
  hourlyRate: number;
  status: 'ativo' | 'inativo';
}

export interface Attendance {
  id: string;
  projectId: string;
  memberId: string;
  date: string;
  hoursWorked: number;
  productivity: number; // 0-100
}

export interface Cost {
  id: string;
  projectId: string;
  stageId?: string;
  category: 'materiais' | 'mao_de_obra' | 'equipamentos' | 'transporte' | 'imprevistos';
  description: string;
  amount: number;
  date: string;
}

export interface Material {
  id: string;
  projectId: string;
  name: string;
  unit: string;
  plannedQuantity: number;
  usedQuantity: number;
  costPerUnit: number;
}

export interface Message {
  id: string;
  projectId: string;
  senderId: string;
  senderName: string;
  text: string;
  timestamp: string;
  attachments?: string[];
}

export interface Document {
  id: string;
  projectId: string;
  name: string;
  type: 'planta' | 'contrato' | 'orcamento' | 'tecnico' | 'foto';
  url: string;
  uploadedAt: string;
}
