import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, HardHat, Users, Calendar, Settings, Menu, X, LogOut, Tag } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { useFirebase } from './FirebaseProvider';

function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

export default function Navigation() {
  const [isOpen, setIsOpen] = React.useState(false);
  const { userProfile, logout } = useFirebase();

  const navItems = [
    { name: 'Dashboard', href: '/', icon: LayoutDashboard },
    { name: 'Obras', href: '/obras', icon: HardHat },
    { name: 'Equipe', href: '/equipe', icon: Users },
    { name: 'Cronograma', href: '/cronograma', icon: Calendar },
    { name: 'Cotações', href: '/cotacoes', icon: Tag },
    { name: 'Configurações', href: '/configuracoes', icon: Settings },
  ];

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  return (
    <>
      {/* Mobile Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-md lg:hidden"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transform transition-transform duration-200 ease-in-out lg:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex flex-col h-full">
          <div className="p-6">
            <h1 className="text-2xl font-bold text-brand-600 flex items-center gap-2">
              <HardHat className="text-brand-500" />
              Edifex
            </h1>
            <p className="text-xs text-slate-500 mt-1">Construindo obras mais inteligentes.</p>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            {navItems.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors",
                    isActive
                      ? "bg-brand-50 text-brand-700"
                      : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                  )
                }
              >
                <item.icon size={20} />
                {item.name}
              </NavLink>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-100 space-y-2">
            <div className="flex items-center gap-3 px-4 py-3">
              <div className="w-8 h-8 rounded-full overflow-hidden bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-xs border border-brand-200">
                {userProfile?.photoUrl ? (
                  <img src={userProfile.photoUrl} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  userProfile?.displayName ? getInitials(userProfile.displayName) : 'U'
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 truncate">
                  {userProfile?.displayName || 'Usuário'}
                </p>
                <p className="text-xs text-slate-500 truncate">
                  {userProfile?.role || 'Membro'}
                </p>
              </div>
            </div>
            
            <button
              onClick={logout}
              className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 transition-colors"
            >
              <LogOut size={20} />
              Sair da conta
            </button>
          </div>
        </div>
      </aside>

      {/* Overlay */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-30 bg-slate-900/20 backdrop-blur-sm lg:hidden"
        />
      )}
    </>
  );
}
