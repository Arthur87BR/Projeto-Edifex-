import React from 'react';
import { Loader2 } from 'lucide-react';
import ImageUpload from './ImageUpload';

const ROLES = [
  'Engenheiro(a)',
  'Arquiteto(a)',
  'Mestre de Obras',
  'Pedreiro',
  'Servente',
  'Eletricista',
  'Encanador',
  'Pintor',
  'Gesseiro',
  'Carpinteiro',
  'Armador',
  'Outro'
];

interface ProjectTeamFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
  stages: any[];
}

export default function ProjectTeamForm({ onSubmit, onCancel, initialData, stages }: ProjectTeamFormProps) {
  const [loading, setLoading] = React.useState(false);
  const [formData, setFormData] = React.useState({
    name: initialData?.name || '',
    role: initialData?.role || ROLES[0],
    phone: initialData?.phone || '',
    type: initialData?.type || 'CLT',
    rate: initialData?.rate || '',
    photoUrl: initialData?.photoUrl || '',
    assignedStages: initialData?.assignedStages || []
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } finally {
      setLoading(false);
    }
  };

  const toggleStage = (stageId: string) => {
    const current = [...formData.assignedStages];
    const index = current.indexOf(stageId);
    if (index > -1) {
      current.splice(index, 1);
    } else {
      current.push(stageId);
    }
    setFormData({ ...formData, assignedStages: current });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <ImageUpload 
        onUploadComplete={(url) => setFormData({ ...formData, photoUrl: url })}
        label="Foto do Membro"
        folder="team"
        currentImageUrl={formData.photoUrl}
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Nome Completo</label>
          <input
            type="text"
            required
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
            placeholder="Ex: João Silva"
          />
        </div>
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Telefone</label>
          <input
            type="tel"
            required
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
            placeholder="(00) 00000-0000"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Função</label>
          <select
            value={formData.role}
            onChange={(e) => setFormData({ ...formData, role: e.target.value })}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none bg-white"
          >
            {ROLES.map(role => (
              <option key={role} value={role}>{role}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-bold text-slate-700 mb-1">Tipo de Contrato</label>
          <select
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none bg-white"
          >
            <option value="CLT">CLT</option>
            <option value="PJ">PJ</option>
            <option value="Diária">Diária</option>
            <option value="Empreitada">Empreitada</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-bold text-slate-700 mb-1">Valor (Diária ou Salário)</label>
        <input
          type="text"
          value={formData.rate}
          onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
          placeholder="Ex: R$ 200,00"
        />
      </div>

      <div>
        <label className="block text-sm font-bold text-slate-700 mb-2">Etapas em que trabalha</label>
        <div className="flex flex-wrap gap-2">
          {stages.map((stage) => (
            <button
              key={stage.id}
              type="button"
              onClick={() => toggleStage(stage.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                formData.assignedStages.includes(stage.id)
                  ? "bg-brand-600 border-brand-600 text-white shadow-md shadow-brand-200"
                  : "bg-white border-slate-200 text-slate-600 hover:border-brand-300"
              }`}
            >
              {stage.name}
            </button>
          ))}
          {stages.length === 0 && (
            <p className="text-xs text-slate-500 italic">Nenhuma etapa cadastrada no projeto.</p>
          )}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          disabled={loading}
          className="flex-1 px-4 py-2 bg-brand-600 text-white rounded-xl font-bold hover:bg-brand-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 size={18} className="animate-spin" /> : 'Salvar'}
        </button>
      </div>
    </form>
  );
}
