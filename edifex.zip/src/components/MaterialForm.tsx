import React from 'react';

interface MaterialFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
}

const MaterialForm: React.FC<MaterialFormProps> = ({ onSubmit, onCancel, initialData }) => {
  const [formData, setFormData] = React.useState({
    name: initialData?.name || '',
    quantity: initialData?.quantity || 0,
    unit: initialData?.unit || 'un',
    minStock: initialData?.minStock || 0,
    category: initialData?.category || 'Básico',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Nome do Material</label>
        <input
          type="text"
          required
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Ex: Cimento CP-II"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Quantidade em Estoque</label>
          <input
            type="number"
            step="0.01"
            required
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.quantity}
            onChange={(e) => setFormData({ ...formData, quantity: parseFloat(e.target.value) })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Unidade</label>
          <select
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.unit}
            onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
          >
            <option value="un">Unidade (un)</option>
            <option value="kg">Quilo (kg)</option>
            <option value="m">Metro (m)</option>
            <option value="m2">Metro Quadrado (m²)</option>
            <option value="m3">Metro Cúbico (m³)</option>
            <option value="l">Litro (l)</option>
            <option value="sc">Saco (sc)</option>
            <option value="mil">Milheiro (mil)</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Estoque Mínimo</label>
          <input
            type="number"
            step="0.01"
            required
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.minStock}
            onChange={(e) => setFormData({ ...formData, minStock: parseFloat(e.target.value) })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Categoria</label>
          <select
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          >
            <option value="Básico">Básico</option>
            <option value="Hidráulico">Hidráulico</option>
            <option value="Elétrico">Elétrico</option>
            <option value="Acabamento">Acabamento</option>
            <option value="Ferramentas">Ferramentas</option>
            <option value="Outros">Outros</option>
          </select>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-xl transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="px-6 py-2 bg-brand-600 text-white font-medium rounded-xl hover:bg-brand-700 transition-colors"
        >
          {initialData ? 'Salvar Alterações' : 'Adicionar Material'}
        </button>
      </div>
    </form>
  );
};

export default MaterialForm;
