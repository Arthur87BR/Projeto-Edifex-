import React from 'react';
import { AlertCircle } from 'lucide-react';

interface TaskFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
  initialData?: any;
  existingTasks?: any[];
}

const TaskForm: React.FC<TaskFormProps> = ({ onSubmit, onCancel, initialData, existingTasks = [] }) => {
  const [formData, setFormData] = React.useState({
    name: initialData?.name || '',
    status: initialData?.status || 'Pendente',
    progress: initialData?.progress || 0,
    startDate: initialData?.startDate || '',
    endDate: initialData?.endDate || '',
    assignee: initialData?.assignee || '',
  });
  const [error, setError] = React.useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const start = new Date(formData.startDate);
    const end = new Date(formData.endDate);

    // 1. Validação de data de início e término
    if (formData.startDate && formData.endDate && start > end) {
      setError('A data de início não pode ser posterior à data de término.');
      return;
    }

    // 2. Validação de sobreposição (opcional, dependendo da regra de negócio, mas solicitada pelo usuário)
    if (formData.startDate && formData.endDate) {
      const overlap = existingTasks.find(task => {
        // Ignorar a própria tarefa se estiver editando
        if (initialData && task.id === initialData.id) return false;
        
        const taskStart = new Date(task.startDate);
        const taskEnd = new Date(task.endDate);
        
        // Verifica se há sobreposição
        return (start <= taskEnd && end >= taskStart);
      });

      if (overlap) {
        setError(`Esta etapa se sobrepõe à etapa "${overlap.name}" (${overlap.startDate} a ${overlap.endDate}).`);
        return;
      }
    }

    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 border border-red-100 rounded-xl flex items-center gap-2 text-red-600 text-sm font-medium">
          <AlertCircle size={18} />
          {error}
        </div>
      )}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Nome da Etapa/Tarefa</label>
        <input
          type="text"
          required
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="Ex: Fundação, Alvenaria, Pintura"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Status</label>
          <select
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          >
            <option value="Pendente">Pendente</option>
            <option value="Em Execução">Em Execução</option>
            <option value="Concluído">Concluído</option>
            <option value="Atrasado">Atrasado</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Progresso (%)</label>
          <input
            type="number"
            min="0"
            max="100"
            required
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.progress}
            onChange={(e) => setFormData({ ...formData, progress: parseInt(e.target.value) })}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Data de Início</label>
          <input
            type="date"
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.startDate}
            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Data de Término</label>
          <input
            type="date"
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
            value={formData.endDate}
            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Responsável</label>
        <input
          type="text"
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none"
          value={formData.assignee}
          onChange={(e) => setFormData({ ...formData, assignee: e.target.value })}
          placeholder="Nome do responsável ou equipe"
        />
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-xl transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="px-6 py-2 bg-brand-600 text-white font-medium rounded-xl hover:bg-brand-700 transition-colors"
        >
          {initialData ? 'Salvar Alterações' : 'Criar Etapa'}
        </button>
      </div>
    </form>
  );
};

export default TaskForm;
