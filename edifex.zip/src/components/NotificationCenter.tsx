import React, { useState, useEffect } from 'react';
import { Bell, X, Info, AlertTriangle, AlertCircle, CheckCircle, ExternalLink } from 'lucide-react';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc, deleteDoc, addDoc, getDocs, limit } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useFirebase } from './FirebaseProvider';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Link } from 'react-router-dom';

function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

export default function NotificationCenter() {
  const { user } = useFirebase();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(20)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setNotifications(docs);
      setUnreadCount(docs.filter((n: any) => !n.read).length);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'notifications');
    });

    return () => unsubscribe();
  }, [user]);

  // Logic to check for deadlines
  useEffect(() => {
    if (!user) return;

    const checkDeadlines = async () => {
      try {
        // Fetch projects
        const projectsSnap = await getDocs(query(collection(db, 'projects'), where('ownerId', '==', user.uid)));
        
        for (const projectDoc of projectsSnap.docs) {
          const projectId = projectDoc.id;
          const projectName = projectDoc.data().name;
          
          // Fetch tasks
          const tasksSnap = await getDocs(collection(db, 'projects', projectId, 'tasks'));
          
          for (const taskDoc of tasksSnap.docs) {
            const task = taskDoc.data();
            const taskId = taskDoc.id;
            
            if (task.status === 'Concluído') continue;
            if (!task.endDate) continue;

            const endDate = new Date(task.endDate);
            const now = new Date();
            const diffTime = endDate.getTime() - now.getTime();
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

            // Check for delayed
            if (diffDays < 0) {
              const notificationId = `delayed_${taskId}`;
              await createNotificationIfNotExist(notificationId, {
                title: 'Etapa Atrasada',
                message: `A etapa "${task.name}" da obra "${projectName}" está atrasada.`,
                type: 'error',
                link: `/obras/${projectId}`
              });
            } 
            // Check for due today
            else if (diffDays === 0) {
              const notificationId = `due_today_${taskId}`;
              await createNotificationIfNotExist(notificationId, {
                title: 'Vence Hoje',
                message: `A etapa "${task.name}" da obra "${projectName}" vence hoje!`,
                type: 'warning',
                link: `/obras/${projectId}`
              });
            }
            // Check for due soon (3 days)
            else if (diffDays <= 3) {
              const notificationId = `due_soon_${taskId}`;
              await createNotificationIfNotExist(notificationId, {
                title: 'Vencimento Próximo',
                message: `A etapa "${task.name}" da obra "${projectName}" vence em ${diffDays} dias.`,
                type: 'info',
                link: `/obras/${projectId}`
              });
            }
          }
        }
      } catch (error) {
        console.error("Error checking deadlines:", error);
      }
    };

    const createNotificationIfNotExist = async (uniqueId: string, data: any) => {
      if (!user) return;
      
      const q = query(
        collection(db, 'notifications'),
        where('userId', '==', user.uid),
        where('uniqueId', '==', uniqueId)
      );
      
      const snap = await getDocs(q);
      if (snap.empty) {
        await addDoc(collection(db, 'notifications'), {
          ...data,
          userId: user.uid,
          uniqueId,
          read: false,
          createdAt: new Date().toISOString()
        });
      }
    };

    // Run check once on load
    checkDeadlines();
  }, [user]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'notifications');
    }
  };

  const markAllAsRead = async () => {
    try {
      const unread = notifications.filter(n => !n.read);
      for (const n of unread) {
        await updateDoc(doc(db, 'notifications', n.id), { read: true });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'notifications');
    }
  };

  const deleteNotification = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'notifications', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'notifications');
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle className="text-amber-500" size={20} />;
      case 'error': return <AlertCircle className="text-red-500" size={20} />;
      case 'success': return <CheckCircle className="text-emerald-500" size={20} />;
      default: return <Info className="text-blue-500" size={20} />;
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-slate-600 hover:bg-slate-100 rounded-full transition-colors"
      >
        <Bell size={24} />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-5 h-5 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-80 md:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-bold text-slate-900">Notificações</h3>
              <div className="flex gap-2">
                {unreadCount > 0 && (
                  <button 
                    onClick={markAllAsRead}
                    className="text-xs font-bold text-brand-600 hover:text-brand-700"
                  >
                    Ler todas
                  </button>
                )}
                <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X size={18} />
                </button>
              </div>
            </div>

            <div className="max-h-[400px] overflow-y-auto">
              {notifications.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {notifications.map((n) => (
                    <div 
                      key={n.id} 
                      className={cn(
                        "p-4 hover:bg-slate-50 transition-colors relative group",
                        !n.read && "bg-brand-50/30"
                      )}
                    >
                      <div className="flex gap-3">
                        <div className="mt-1">{getIcon(n.type)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start gap-2">
                            <p className={cn("text-sm font-bold truncate", !n.read ? "text-slate-900" : "text-slate-600")}>
                              {n.title}
                            </p>
                            <span className="text-[10px] text-slate-400 whitespace-nowrap">
                              {format(new Date(n.createdAt), "dd MMM, HH:mm", { locale: ptBR })}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                            {n.message}
                          </p>
                          {n.link && (
                            <Link 
                              to={n.link}
                              onClick={() => {
                                markAsRead(n.id);
                                setIsOpen(false);
                              }}
                              className="inline-flex items-center gap-1 text-[10px] font-bold text-brand-600 mt-2 hover:underline"
                            >
                              Ver Detalhes
                              <ExternalLink size={10} />
                            </Link>
                          )}
                        </div>
                      </div>
                      <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                        {!n.read && (
                          <button 
                            onClick={() => markAsRead(n.id)}
                            className="p-1 bg-white rounded-md shadow-sm border border-slate-200 text-slate-400 hover:text-brand-600"
                            title="Marcar como lida"
                          >
                            <CheckCircle size={14} />
                          </button>
                        )}
                        <button 
                          onClick={() => deleteNotification(n.id)}
                          className="p-1 bg-white rounded-md shadow-sm border border-slate-200 text-slate-400 hover:text-red-600"
                          title="Excluir"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-400">
                    <Bell size={24} />
                  </div>
                  <p className="text-sm text-slate-500">Nenhuma notificação por enquanto.</p>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
