import React, { useState } from 'react';
import ImageUpload from './ImageUpload';

interface ProjectFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export default function ProjectForm({ onSubmit, onCancel }: ProjectFormProps) {
  const [imageUrl, setImageUrl] = useState('');

  return (
    <form className="space-y-4" onSubmit={(e) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const data = Object.fromEntries(formData);
      onSubmit({ ...data, imageUrl });
    }}>
      <ImageUpload 
        onUploadComplete={setImageUrl} 
        label="Imagem de Capa da Obra" 
        folder="projects"
      />

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Nome da Obra</label>
        <input
          name="name"
          required
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
          placeholder="Ex: Residencial Aurora"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Cliente</label>
        <input
          name="client"
          required
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
          placeholder="Nome do cliente"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">Localização</label>
        <input
          name="location"
          required
          className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
          placeholder="Endereço completo"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Orçamento Estimado</label>
          <input
            name="budget"
            type="number"
            required
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
            placeholder="R$ 0,00"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Prazo Estimado</label>
          <input
            name="endDate"
            type="date"
            required
            className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none transition-all"
          />
        </div>
      </div>

      <div className="flex gap-3 mt-8">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 transition-colors"
        >
          Cancelar
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2 bg-brand-600 text-white rounded-xl font-medium hover:bg-brand-700 transition-colors"
        >
          Criar Obra
        </button>
      </div>
    </form>
  );
}
