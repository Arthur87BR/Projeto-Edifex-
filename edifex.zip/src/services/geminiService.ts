import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function predictDelay(projectData: any) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analise os seguintes dados de uma obra e preveja possíveis atrasos. Retorne um JSON com "delayProbability" (0-100), "estimatedDays" e "reasons" (array de strings).
      Dados: ${JSON.stringify(projectData)}`,
      config: {
        responseMimeType: "application/json"
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Erro ao prever atraso:", error);
    return { delayProbability: 0, estimatedDays: 0, reasons: ["Erro na análise de IA"] };
  }
}

export async function analyzeCosts(costs: any[]) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analise estes custos de obra e identifique anomalias ou sugestões de economia: ${JSON.stringify(costs)}. Responda em português.`,
    });
    return response.text;
  } catch (error) {
    console.error("Erro ao analisar custos:", error);
    return "Não foi possível analisar os custos no momento.";
  }
}

export async function suggestBudget(previousProjects: any[]) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Com base no histórico destas obras: ${JSON.stringify(previousProjects)}, sugira um orçamento estimado para uma nova obra similar.`,
    });
    return response.text;
  } catch (error) {
    console.error("Erro ao sugerir orçamento:", error);
    return "Não foi possível sugerir um orçamento no momento.";
  }
}
