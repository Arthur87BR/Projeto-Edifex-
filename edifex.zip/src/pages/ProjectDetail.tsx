import React from 'react';
import { useParams } from 'react-router-dom';
import { 
  BarChart3, 
  ClipboardList, 
  Users, 
  DollarSign, 
  Package, 
  FileText, 
  Calendar,
  Plus,
  Camera,
  MessageSquare,
  Trash2,
  Edit2,
  AlertTriangle,
  Sparkles,
  Loader2,
  CloudSun
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import Modal from '../components/Modal';
import DailyLogForm from '../components/DailyLogForm';
import CostForm from '../components/CostForm';
import TaskForm from '../components/TaskForm';
import DocumentForm from '../components/DocumentForm';
import MaterialForm from '../components/MaterialForm';
import ProjectTeamForm from '../components/ProjectTeamForm';
import { doc, onSnapshot, collection, query, where, addDoc, updateDoc, deleteDoc, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { analyzeCosts, predictDelay } from '../services/geminiService';
import Markdown from 'react-markdown';

function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

type TabType = 'overview' | 'stages' | 'daily_log' | 'team' | 'costs' | 'materials' | 'documents';

export default function ProjectDetail() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = React.useState<TabType>('overview');
  const [isLogModalOpen, setIsLogModalOpen] = React.useState(false);
  const [isCostModalOpen, setIsCostModalOpen] = React.useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = React.useState(false);
  const [isDocModalOpen, setIsDocModalOpen] = React.useState(false);
  const [isMaterialModalOpen, setIsMaterialModalOpen] = React.useState(false);
  const [isTeamModalOpen, setIsTeamModalOpen] = React.useState(false);
  
  const [editingItem, setEditingItem] = React.useState<any>(null);
  
  const [project, setProject] = React.useState<any>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!id) return;

    const unsubscribe = onSnapshot(doc(db, 'projects', id), (docSnap) => {
      if (docSnap.exists()) {
        setProject({ id: docSnap.id, ...docSnap.data() });
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `projects/${id}`);
    });

    return () => unsubscribe();
  }, [id]);

  const updateProjectSpent = async (projectId: string) => {
    try {
      const costsSnap = await getDocs(collection(db, 'projects', projectId, 'costs'));
      const totalSpent = costsSnap.docs.reduce((acc, doc) => acc + (doc.data().amount || 0), 0);
      await updateDoc(doc(db, 'projects', projectId), { spent: totalSpent });
    } catch (error) {
      console.error("Error updating project spent:", error);
    }
  };

  const updateProjectProgress = async (projectId: string) => {
    try {
      const tasksSnap = await getDocs(collection(db, 'projects', projectId, 'tasks'));
      const tasks = tasksSnap.docs.map(doc => doc.data());
      
      if (tasks.length === 0) {
        await updateDoc(doc(db, 'projects', projectId), { progress: 0 });
        return;
      }

      const totalProgress = tasks.reduce((acc, task) => acc + (Number(task.progress) || 0), 0);
      const averageProgress = Math.round(totalProgress / tasks.length);
      
      // Lógica de atualização de status baseada no progresso e status das etapas
      const hasDelayedTask = tasks.some(task => task.status === 'Atrasado');
      
      let status = 'Planejamento';
      if (averageProgress === 100) {
        status = 'Concluído';
      } else if (hasDelayedTask) {
        status = 'Atrasado';
      } else if (averageProgress > 0) {
        status = 'Em Andamento';
      }

      await updateDoc(doc(db, 'projects', projectId), { 
        progress: Math.min(averageProgress, 100),
        status: status
      });
    } catch (error) {
      console.error("Error updating project progress:", error);
    }
  };

  const handleAddCost = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'costs', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'costs'), {
          ...data,
          projectId: id
        });
      }
      await updateProjectSpent(id);
      await updateProjectProgress(id);
      setIsCostModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/costs`);
    }
  };

  const handleDeleteCost = async (costId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja excluir este custo?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'costs', costId));
      await updateProjectSpent(id);
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/costs`);
    }
  };

  const handleAddTask = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'tasks', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'tasks'), {
          ...data,
          projectId: id
        });
      }
      await updateProjectProgress(id);
      setIsTaskModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/tasks`);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja excluir esta etapa?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'tasks', taskId));
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/tasks`);
    }
  };

  const handleAddDoc = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'documents', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'documents'), {
          ...data,
          projectId: id
        });
      }
      setIsDocModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/documents`);
    }
  };

  const handleDeleteDoc = async (docId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja excluir este documento?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'documents', docId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/documents`);
    }
  };

  const handleAddLog = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'daily_logs', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'daily_logs'), {
          ...data,
          projectId: id
        });
      }
      await updateProjectProgress(id);
      setIsLogModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/daily_logs`);
    }
  };

  const handleDeleteLog = async (logId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja excluir este registro?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'daily_logs', logId));
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/daily_logs`);
    }
  };

  const handleAddMaterial = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'materials', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'materials'), {
          ...data,
          projectId: id
        });
      }
      await updateProjectProgress(id);
      setIsMaterialModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/materials`);
    }
  };

  const handleDeleteMaterial = async (materialId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja excluir este material?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'materials', materialId));
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/materials`);
    }
  };

  const handleAddTeamMember = async (data: any) => {
    if (!id) return;
    try {
      if (editingItem) {
        await updateDoc(doc(db, 'projects', id, 'team', editingItem.id), data);
      } else {
        await addDoc(collection(db, 'projects', id, 'team'), {
          ...data,
          projectId: id
        });
      }
      await updateProjectProgress(id);
      setIsTeamModalOpen(false);
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, editingItem ? OperationType.UPDATE : OperationType.CREATE, `projects/${id}/team`);
    }
  };

  const handleDeleteTeamMember = async (memberId: string) => {
    if (!id || !window.confirm('Tem certeza que deseja remover este membro da obra?')) return;
    try {
      await deleteDoc(doc(db, 'projects', id, 'team', memberId));
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `projects/${id}/team`);
    }
  };

  const handleTogglePresence = async (member: any) => {
    if (!id) return;
    try {
      await updateDoc(doc(db, 'projects', id, 'team', member.id), {
        isPresent: !member.isPresent
      });
      await updateProjectProgress(id);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `projects/${id}/team`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-slate-900">Projeto não encontrado</h2>
        <p className="text-slate-500">O projeto que você está procurando não existe ou foi removido.</p>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Geral', icon: BarChart3 },
    { id: 'stages', label: 'Etapas', icon: Calendar },
    { id: 'daily_log', label: 'Diário', icon: ClipboardList },
    { id: 'team', label: 'Equipe', icon: Users },
    { id: 'costs', label: 'Custos', icon: DollarSign },
    { id: 'materials', label: 'Materiais', icon: Package },
    { id: 'documents', label: 'Docs', icon: FileText },
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
        <div>
          <div className="flex items-center gap-2 text-sm text-brand-600 font-medium mb-1">
            <span className="px-2 py-0.5 bg-brand-50 rounded-full">{project.status}</span>
            <span>•</span>
            <span>{project.name}</span>
          </div>
          <h1 className="text-3xl font-bold text-slate-900">{project.name}</h1>
          <p className="text-slate-500">{project.address || 'Endereço não informado'}</p>
        </div>
        
        <div className="flex gap-2">
          <button className="p-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50">
            <MessageSquare size={20} />
          </button>
          <button 
            onClick={() => setIsLogModalOpen(true)}
            className="bg-brand-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-brand-700 transition-colors flex items-center gap-2"
          >
            <Plus size={20} />
            Novo Registro
          </button>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className="flex overflow-x-auto pb-2 scrollbar-hide gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as TabType)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all",
              activeTab === tab.id
                ? "bg-brand-600 text-white shadow-md shadow-brand-200"
                : "bg-white text-slate-600 border border-slate-200 hover:border-brand-300"
            )}
          >
            <tab.icon size={18} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="mt-6">
        {activeTab === 'overview' && <OverviewTab project={project} />}
        {activeTab === 'daily_log' && (
          <DailyLogTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsLogModalOpen(true); }}
            onEdit={(item) => { setEditingItem(item); setIsLogModalOpen(true); }}
            onDelete={handleDeleteLog}
          />
        )}
        {activeTab === 'costs' && (
          <CostsTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsCostModalOpen(true); }} 
            onEdit={(item) => { setEditingItem(item); setIsCostModalOpen(true); }}
            onDelete={handleDeleteCost}
          />
        )}
        {activeTab === 'materials' && (
          <MaterialsTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsMaterialModalOpen(true); }}
            onEdit={(item) => { setEditingItem(item); setIsMaterialModalOpen(true); }}
            onDelete={handleDeleteMaterial}
          />
        )}
        {activeTab === 'team' && (
          <TeamTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsTeamModalOpen(true); }}
            onEdit={(item) => { setEditingItem(item); setIsTeamModalOpen(true); }}
            onDelete={handleDeleteTeamMember}
            onTogglePresence={handleTogglePresence}
          />
        )}
        {activeTab === 'stages' && (
          <StagesTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsTaskModalOpen(true); }}
            onEdit={(item) => { setEditingItem(item); setIsTaskModalOpen(true); }}
            onDelete={handleDeleteTask}
          />
        )}
        {activeTab === 'documents' && (
          <DocumentsTab 
            projectId={project.id} 
            onAdd={() => { setEditingItem(null); setIsDocModalOpen(true); }}
            onEdit={(item) => { setEditingItem(item); setIsDocModalOpen(true); }}
            onDelete={handleDeleteDoc}
          />
        )}
      </div>

      <Modal 
        isOpen={isLogModalOpen} 
        onClose={() => { setIsLogModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Registro Diário" : "Novo Registro Diário"}
      >
        <DailyLogForm 
          onSubmit={handleAddLog} 
          onCancel={() => { setIsLogModalOpen(false); setEditingItem(null); }}
          initialData={editingItem}
        />
      </Modal>

      <Modal 
        isOpen={isCostModalOpen} 
        onClose={() => { setIsCostModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Gasto" : "Lançar Novo Gasto"}
      >
        <CostForm 
          onSubmit={handleAddCost} 
          onCancel={() => { setIsCostModalOpen(false); setEditingItem(null); }}
          initialData={editingItem}
        />
      </Modal>

      <Modal 
        isOpen={isTaskModalOpen} 
        onClose={() => { setIsTaskModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Etapa" : "Nova Etapa da Obra"}
      >
        <StagesFetcher projectId={project.id}>
          {(stages) => (
            <TaskForm 
              onSubmit={handleAddTask} 
              onCancel={() => { setIsTaskModalOpen(false); setEditingItem(null); }}
              initialData={editingItem}
              existingTasks={stages}
            />
          )}
        </StagesFetcher>
      </Modal>

      <Modal 
        isOpen={isDocModalOpen} 
        onClose={() => { setIsDocModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Documento" : "Adicionar Documento"}
      >
        <DocumentForm 
          onSubmit={handleAddDoc} 
          onCancel={() => { setIsDocModalOpen(false); setEditingItem(null); }}
          initialData={editingItem}
        />
      </Modal>

      <Modal 
        isOpen={isMaterialModalOpen} 
        onClose={() => { setIsMaterialModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Material" : "Adicionar Material"}
      >
        <MaterialForm 
          onSubmit={handleAddMaterial} 
          onCancel={() => { setIsMaterialModalOpen(false); setEditingItem(null); }}
          initialData={editingItem}
        />
      </Modal>

      <Modal 
        isOpen={isTeamModalOpen} 
        onClose={() => { setIsTeamModalOpen(false); setEditingItem(null); }} 
        title={editingItem ? "Editar Membro da Obra" : "Adicionar Membro da Obra"}
      >
        <StagesFetcher projectId={project.id}>
          {(stages) => (
            <ProjectTeamForm 
              onSubmit={handleAddTeamMember} 
              onCancel={() => { setIsTeamModalOpen(false); setEditingItem(null); }}
              initialData={editingItem}
              stages={stages}
            />
          )}
        </StagesFetcher>
      </Modal>
    </div>
  );
}

function StagesFetcher({ projectId, children }: { projectId: string, children: (stages: any[]) => React.ReactNode }) {
  const [stages, setStages] = React.useState<any[]>([]);
  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'tasks');
    getDocs(q).then(snap => {
      setStages(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
  }, [projectId]);
  return <>{children(stages)}</>;
}

function TeamTab({ projectId, onAdd, onEdit, onDelete, onTogglePresence }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void, onTogglePresence: (member: any) => void }) {
  const [members, setMembers] = React.useState<any[]>([]);
  const [stages, setStages] = React.useState<any[]>([]);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'team');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMembers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/team`);
    });

    const stagesQ = collection(db, 'projects', projectId, 'tasks');
    getDocs(stagesQ).then(snap => {
      setStages(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });

    return () => unsubscribe();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Equipe da Obra</h3>
        <button 
          onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
        >
          <Plus size={18} />
          Adicionar Membro
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {members.map((member) => (
          <div key={member.id} className="glass-card p-6 rounded-2xl relative group">
            <div className="flex items-center gap-4 mb-4">
              {member.photoUrl ? (
                <img 
                  src={member.photoUrl} 
                  alt={member.name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-brand-100"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-lg">
                  {member.name.charAt(0)}
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-slate-900 truncate">{member.name}</h4>
                <p className="text-xs text-slate-500">{member.role} • {member.type}</p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEdit(member)} className="p-1 text-slate-400 hover:text-brand-600">
                    <Edit2 size={16} />
                  </button>
                  <button onClick={() => onDelete(member.id)} className="p-1 text-slate-400 hover:text-red-600">
                    <Trash2 size={16} />
                  </button>
                </div>
                <button 
                  onClick={() => onTogglePresence(member)}
                  className={cn(
                    "px-2 py-1 rounded-lg text-[10px] font-bold transition-colors",
                    member.isPresent 
                      ? "bg-emerald-100 text-emerald-700 border border-emerald-200" 
                      : "bg-slate-100 text-slate-500 border border-slate-200"
                  )}
                >
                  {member.isPresent ? "Presente" : "Ausente"}
                </button>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Telefone</span>
                <span className="font-medium">{member.phone}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Valor</span>
                <span className="font-medium">{member.rate || 'N/A'}</span>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Etapas Associadas</p>
                <div className="flex flex-wrap gap-1">
                  {member.assignedStages?.map((stageId: string) => {
                    const stage = stages.find(s => s.id === stageId);
                    return (
                      <span key={stageId} className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-medium">
                        {stage?.name || 'Etapa removida'}
                      </span>
                    );
                  })}
                  {(!member.assignedStages || member.assignedStages.length === 0) && (
                    <span className="text-[10px] text-slate-400 italic">Nenhuma etapa associada</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
        {members.length === 0 && (
          <div className="col-span-full text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhum membro adicionado a esta obra.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function OverviewTab({ project }: { project: any }) {
  const [delayPrediction, setDelayPrediction] = React.useState<any>(null);
  const [isPredicting, setIsPredicting] = React.useState(false);
  const budget = project.budget || 0;
  const spent = project.spent || 0;
  const financialProgress = budget > 0 ? (spent / budget) * 100 : 0;

  const handlePredictDelay = async () => {
    setIsPredicting(true);
    try {
      // Fetch some tasks to give context
      const tasksSnap = await getDocs(collection(db, 'projects', project.id, 'stages'));
      const tasks = tasksSnap.docs.map(d => d.data());
      
      const prediction = await predictDelay({ ...project, tasks });
      setDelayPrediction(prediction);
    } catch (error) {
      console.error(error);
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex justify-between items-start mb-4">
            <h3 className="font-bold text-lg">Progresso Geral</h3>
            <button 
              onClick={handlePredictDelay}
              disabled={isPredicting}
              className="flex items-center gap-2 px-3 py-1.5 bg-brand-50 text-brand-600 rounded-lg text-xs font-bold hover:bg-brand-100 transition-colors disabled:opacity-50"
            >
              {isPredicting ? <Loader2 size={14} className="animate-spin" /> : <Sparkles size={14} />}
              Prever Atrasos
            </button>
          </div>
          
          {delayPrediction && (
            <div className={cn(
              "mb-6 p-4 rounded-xl border",
              delayPrediction.delayProbability > 50 ? "bg-red-50 border-red-100" : "bg-emerald-50 border-emerald-100"
            )}>
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle size={18} className={delayPrediction.delayProbability > 50 ? "text-red-600" : "text-emerald-600"} />
                <h4 className="font-bold text-sm">Análise de Risco de Atraso</h4>
              </div>
              <p className="text-sm mb-2">
                Probabilidade: <span className="font-bold">{delayPrediction.delayProbability}%</span>
                {delayPrediction.estimatedDays > 0 && (
                  <> | Atraso estimado: <span className="font-bold">{delayPrediction.estimatedDays} dias</span></>
                )}
              </p>
              <ul className="text-xs space-y-1 list-disc list-inside text-slate-600">
                {delayPrediction.reasons.map((reason: string, i: number) => (
                  <li key={i}>{reason}</li>
                ))}
              </ul>
              <button 
                onClick={() => setDelayPrediction(null)}
                className="mt-3 text-[10px] uppercase tracking-wider font-bold text-slate-400 hover:text-slate-600"
              >
                Ocultar Previsão
              </button>
            </div>
          )}

          <div className="flex items-end gap-4 mb-2">
            <span className="text-4xl font-bold text-brand-600">{project.progress}%</span>
            <span className="text-sm text-slate-500 pb-1">Concluído</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-4">
            <div 
              className={cn(
                "h-4 rounded-full transition-all duration-500",
                project.status === 'Atrasado' ? "bg-red-500" : "bg-brand-500"
              )} 
              style={{ width: `${project.progress}%` }}
            ></div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            <div>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Início</p>
              <p className="font-medium">{project.startDate || 'N/A'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Previsão</p>
              <p className="font-medium">{project.endDate || 'N/A'}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 uppercase font-bold tracking-wider">Status</p>
              <p className={cn(
                "font-medium",
                project.status === 'Atrasado' ? "text-red-600" : 
                project.status === 'Concluído' ? "text-emerald-600" :
                project.status === 'Em Andamento' ? "text-blue-600" :
                "text-slate-600"
              )}>{project.status}</p>
            </div>
          </div>
        </div>

        <div className="glass-card p-6 rounded-2xl">
          <h3 className="font-bold text-lg mb-4">Últimas Atividades</h3>
          <div className="space-y-4">
            <p className="text-sm text-slate-500 italic">Nenhuma atividade registrada recentemente.</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="glass-card p-6 rounded-2xl">
          <h3 className="font-bold text-lg mb-4">Resumo Financeiro</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-500">Orçado</span>
                <span className="font-bold">R$ {budget.toLocaleString('pt-BR')}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-slate-300 h-2 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-500">Gasto Real</span>
                <span className="font-bold text-brand-600">R$ {spent.toLocaleString('pt-BR')}</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div className="bg-brand-500 h-2 rounded-full" style={{ width: `${Math.min(financialProgress, 100)}%` }}></div>
              </div>
            </div>
          </div>
          <button className="w-full mt-6 py-2 text-sm font-medium text-brand-600 bg-brand-50 rounded-xl hover:bg-brand-100 transition-colors">
            Ver Detalhes Financeiros
          </button>
        </div>
      </div>
    </div>
  );
}

function DailyLogTab({ projectId, onAdd, onEdit, onDelete }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void }) {
  const [logs, setLogs] = React.useState<any[]>([]);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'daily_logs');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/daily_logs`);
    });
    return () => unsubscribe();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Diário de Obra</h3>
        <button 
          onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
        >
          <Plus size={18} />
          Novo Registro
        </button>
      </div>

      <div className="space-y-4">
        {logs.map((log) => (
          <div key={log.id} className="glass-card p-6 rounded-2xl">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-brand-50 flex flex-col items-center justify-center text-brand-600">
                  <span className="text-xs font-bold uppercase">{new Date(log.date).toLocaleDateString('pt-BR', { month: 'short' })}</span>
                  <span className="text-lg font-bold leading-none">{new Date(log.date).getDate()}</span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">Relatório Diário</h4>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <CloudSun size={14} />
                    <span className="capitalize">{log.weather}</span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => onEdit(log)} className="p-2 text-slate-400 hover:text-brand-600 transition-colors border border-slate-200 rounded-xl">
                  <Edit2 size={18} />
                </button>
                <button onClick={() => onDelete(log.id)} className="p-2 text-slate-400 hover:text-red-600 transition-colors border border-slate-200 rounded-xl">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            
            <div className="space-y-3">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Atividades</p>
                <p className="text-sm text-slate-600 leading-relaxed">{log.activities}</p>
              </div>
              {log.problems && (
                <div className="p-3 bg-red-50 rounded-xl border border-red-100">
                  <p className="text-xs font-bold text-red-600 uppercase tracking-wider mb-1">Problemas / Impedimentos</p>
                  <p className="text-sm text-red-700">{log.problems}</p>
                </div>
              )}
            </div>
          </div>
        ))}
        {logs.length === 0 && (
          <div className="text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhum registro diário encontrado.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function CostsTab({ projectId, onAdd, onEdit, onDelete }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void }) {
  const [costs, setCosts] = React.useState<any[]>([]);
  const [aiAnalysis, setAiAnalysis] = React.useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = React.useState(false);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'costs');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setCosts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/costs`);
    });
    return () => unsubscribe();
  }, [projectId]);

  const handleAiAnalysis = async () => {
    if (costs.length === 0) return;
    setIsAnalyzing(true);
    try {
      const analysis = await analyzeCosts(costs);
      setAiAnalysis(analysis || "Não foi possível gerar a análise.");
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Controle de Custos</h3>
        <div className="flex gap-2">
          <button 
            onClick={handleAiAnalysis}
            disabled={isAnalyzing || costs.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-brand-50 text-brand-600 rounded-xl text-sm font-medium hover:bg-brand-100 transition-colors disabled:opacity-50"
          >
            {isAnalyzing ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
            Análise IA
          </button>
          <button 
            onClick={onAdd}
            className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
          >
            <Plus size={18} />
            Lançar Gasto
          </button>
        </div>
      </div>

      {aiAnalysis && (
        <div className="glass-card p-6 rounded-2xl bg-brand-50/50 border-brand-100">
          <div className="flex items-center gap-2 text-brand-600 font-bold mb-3">
            <Sparkles size={20} />
            <h4>Análise Inteligente de Custos</h4>
          </div>
          <div className="text-sm text-slate-700 prose prose-slate max-w-none">
            <Markdown>{aiAnalysis}</Markdown>
          </div>
          <button 
            onClick={() => setAiAnalysis(null)}
            className="mt-4 text-xs text-slate-400 hover:text-slate-600 font-medium"
          >
            Fechar Análise
          </button>
        </div>
      )}

      <div className="glass-card rounded-2xl overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider font-bold">
              <th className="px-6 py-4">Descrição</th>
              <th className="px-6 py-4">Categoria</th>
              <th className="px-6 py-4">Data</th>
              <th className="px-6 py-4">Valor</th>
              <th className="px-6 py-4 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {costs.map((cost) => (
              <tr key={cost.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 text-sm font-medium text-slate-900">{cost.description}</td>
                <td className="px-6 py-4 text-sm text-slate-600">{cost.category}</td>
                <td className="px-6 py-4 text-sm text-slate-600">{cost.date}</td>
                <td className="px-6 py-4 text-sm font-bold text-slate-900">R$ {cost.amount.toLocaleString('pt-BR')}</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => onEdit(cost)} className="p-1 text-slate-400 hover:text-brand-600 transition-colors">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => onDelete(cost.id)} className="p-1 text-slate-400 hover:text-red-600 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {costs.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-slate-500">Nenhum custo registrado.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function MaterialsTab({ projectId, onAdd, onEdit, onDelete }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void }) {
  const [materials, setMaterials] = React.useState<any[]>([]);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'materials');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMaterials(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/materials`);
    });
    return () => unsubscribe();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Gestão de Materiais</h3>
        <button 
          onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
        >
          <Plus size={18} />
          Adicionar Material
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materials.map((material) => (
          <div key={material.id} className="glass-card p-6 rounded-2xl">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="font-bold text-slate-900">{material.name}</h4>
                <p className="text-xs text-slate-500">{material.category}</p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => onEdit(material)} className="p-1 text-slate-400 hover:text-brand-600">
                  <Edit2 size={16} />
                </button>
                <button onClick={() => onDelete(material.id)} className="p-1 text-slate-400 hover:text-red-600">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            
            <div className="flex items-end justify-between">
              <div>
                <p className="text-xs text-slate-400 uppercase font-bold tracking-wider mb-1">Estoque</p>
                <div className="flex items-baseline gap-1">
                  <span className={cn(
                    "text-2xl font-bold",
                    material.quantity <= material.minStock ? "text-red-600" : "text-slate-900"
                  )}>
                    {material.quantity}
                  </span>
                  <span className="text-sm text-slate-500 font-medium">{material.unit}</span>
                </div>
              </div>
              {material.quantity <= material.minStock && (
                <div className="flex items-center gap-1 text-red-600 text-xs font-bold bg-red-50 px-2 py-1 rounded-lg">
                  <AlertTriangle size={14} />
                  Baixo Estoque
                </div>
              )}
            </div>
          </div>
        ))}
        {materials.length === 0 && (
          <div className="col-span-full text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhum material cadastrado.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function StagesTab({ projectId, onAdd, onEdit, onDelete }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void }) {
  const [tasks, setTasks] = React.useState<any[]>([]);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'tasks');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/tasks`);
    });
    return () => unsubscribe();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Etapas da Obra</h3>
        <button 
          onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
        >
          <Plus size={18} />
          Nova Etapa
        </button>
      </div>

      <div className="space-y-4">
        {tasks.map((task) => (
          <div key={task.id} className="glass-card p-6 rounded-2xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-1">
                  <h4 className="font-bold text-slate-900">{task.name}</h4>
                  <span className={cn(
                    "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    task.status === 'Concluído' ? "bg-emerald-50 text-emerald-700" : 
                    task.status === 'Em Execução' ? "bg-blue-50 text-blue-700" : 
                    task.status === 'Atrasado' ? "bg-red-50 text-red-700" :
                    "bg-slate-50 text-slate-500"
                  )}>
                    {task.status}
                  </span>
                </div>
                <p className="text-xs text-slate-500 flex items-center gap-1">
                  <Calendar size={12} />
                  {task.startDate} - {task.endDate}
                </p>
              </div>
              
              <div className="flex-1 max-w-xs">
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-medium">Progresso</span>
                  <span className="font-bold">{task.progress}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div 
                    className={cn(
                      "h-2 rounded-full transition-all duration-500",
                      task.status === 'Atrasado' ? "bg-red-500" :
                      task.progress === 100 ? "bg-emerald-500" : "bg-brand-500"
                    )} 
                    style={{ width: `${task.progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => onEdit(task)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 border border-slate-200 rounded-xl hover:bg-slate-50"
                >
                  Editar
                </button>
                <button 
                  onClick={() => onDelete(task.id)}
                  className="p-2 text-slate-400 hover:text-red-600 transition-colors border border-slate-200 rounded-xl"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          </div>
        ))}
        {tasks.length === 0 && (
          <div className="text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhuma etapa cadastrada.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function DocumentsTab({ projectId, onAdd, onEdit, onDelete }: { projectId: string, onAdd: () => void, onEdit: (item: any) => void, onDelete: (id: string) => void }) {
  const [docs, setDocs] = React.useState<any[]>([]);

  React.useEffect(() => {
    const q = collection(db, 'projects', projectId, 'documents');
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setDocs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `projects/${projectId}/documents`);
    });
    return () => unsubscribe();
  }, [projectId]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Documentos da Obra</h3>
        <button 
          onClick={onAdd}
          className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-medium"
        >
          <Plus size={18} />
          Upload
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {docs.map((docItem) => (
          <div key={docItem.id} className="glass-card p-4 rounded-2xl flex items-start gap-4 hover:border-brand-300 transition-colors group">
            <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
              <FileText className="text-slate-500" size={24} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start">
                <h4 className="font-bold text-slate-900 text-sm truncate">{docItem.name}</h4>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => onEdit(docItem)} className="p-1 text-slate-400 hover:text-brand-600">
                    <Edit2 size={14} />
                  </button>
                  <button onClick={() => onDelete(docItem.id)} className="p-1 text-slate-400 hover:text-red-600">
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <p className="text-xs text-slate-500">{docItem.type}</p>
              <p className="text-[10px] text-slate-400 mt-1">Enviado em {docItem.uploadDate}</p>
              <a 
                href={docItem.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[10px] text-brand-600 hover:underline mt-2 inline-block"
              >
                Ver Documento
              </a>
            </div>
          </div>
        ))}
        {docs.length === 0 && (
          <div className="col-span-full text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhum documento encontrado.</p>
          </div>
        )}
      </div>
    </div>
  );
}




