import React, { useState } from 'react';
import { useFirebase } from '../components/FirebaseProvider';
import { doc, setDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { updateProfile } from 'firebase/auth';
import { Loader2, User, Briefcase, Building2, Users } from 'lucide-react';

const Onboarding: React.FC = () => {
  const { user, refreshProfile } = useFirebase();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.displayName || '',
    role: 'Engenheiro', // Valor padrão conforme solicitado
    company: '',
    hasMembers: false
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    try {
      // Update Auth Profile
      await updateProfile(user, { displayName: formData.name });
      
      // Save to Firestore
      await setDoc(doc(db, 'users', user.uid), {
        displayName: formData.name,
        email: user.email,
        role: formData.role,
        company: formData.company,
        hasMembers: formData.hasMembers,
        createdAt: new Date().toISOString()
      });
      await refreshProfile();
    } catch (error) {
      console.error("Error saving profile:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="glass-card p-10 rounded-3xl max-w-lg w-full shadow-xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Bem-vindo ao Edifex!</h1>
          <p className="text-slate-500">Vamos configurar seu perfil para começar.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
              <User size={16} /> Nome Completo
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all"
              placeholder="Seu nome"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
              <Briefcase size={16} /> Sua Função
            </label>
            <select
              required
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all bg-white"
            >
              <option value="Engenheiro">Engenheiro(a)</option>
              <option value="Arquiteto">Arquiteto(a)</option>
              <option value="Mestre de Obras">Mestre de Obras</option>
              <option value="Proprietário">Proprietário(a)</option>
              <option value="Outro">Outro</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-bold text-slate-700 mb-2 flex items-center gap-2">
              <Building2 size={16} /> Nome da Empresa (Opcional)
            </label>
            <input
              type="text"
              value={formData.company}
              onChange={(e) => setFormData({ ...formData, company: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-brand-500 outline-none transition-all"
              placeholder="Sua empresa"
            />
          </div>

          <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <div className="bg-white p-2 rounded-lg shadow-sm">
              <Users size={20} className="text-brand-600" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold text-slate-700">Você possui equipe?</p>
              <p className="text-xs text-slate-500">Marque se você trabalha com outros membros.</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                className="sr-only peer"
                checked={formData.hasMembers}
                onChange={(e) => setFormData({ ...formData, hasMembers: e.target.checked })}
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-600"></div>
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-brand-600 text-white py-4 rounded-xl font-bold hover:bg-brand-700 transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="animate-spin" size={20} /> : "Finalizar Cadastro"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Onboarding;
