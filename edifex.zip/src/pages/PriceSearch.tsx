import React, { useState, useMemo } from 'react';
import { Search, ShoppingCart, ExternalLink, Sparkles, Loader2, TrendingDown, Info, AlertCircle, Filter, ArrowUpDown, Store, CheckCircle2 } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

interface PriceResult {
  material: string;
  price: string;
  store: string;
  link: string;
  description: string;
}

type SortOrder = 'asc' | 'desc' | 'none';

export default function PriceSearch() {
  const [query, setQuery] = useState('');
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([]);
  const [selectedStores, setSelectedStores] = useState<string[]>([]);
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [directLinkEnabled, setDirectLinkEnabled] = useState(true);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<PriceResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  const toggleMaterial = (material: string) => {
    setSelectedMaterials(prev => 
      prev.includes(material) ? prev.filter(m => m !== material) : [...prev, material]
    );
  };

  const toggleStore = (store: string) => {
    setSelectedStores(prev => 
      prev.includes(store) ? prev.filter(s => s !== store) : [...prev, store]
    );
  };

  const parsePrice = (priceStr: string): number => {
    // Remove R$, spaces, and convert Brazilian format (1.234,56) to standard (1234.56)
    const cleaned = priceStr.replace(/[R$\s.]/g, '').replace(',', '.');
    return parseFloat(cleaned) || 0;
  };

  const minPrice = useMemo(() => {
    if (results.length === 0) return 0;
    return Math.min(...results.map(r => parsePrice(r.price)));
  }, [results]);

  const sortedResults = useMemo(() => {
    if (sortOrder === 'none') return results;
    return [...results].sort((a, b) => {
      const priceA = parsePrice(a.price);
      const priceB = parsePrice(b.price);
      return sortOrder === 'asc' ? priceA - priceB : priceB - priceA;
    });
  }, [results, sortOrder]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalQuery = [query, ...selectedMaterials].filter(Boolean).join(', ');
    if (!finalQuery) return;

    setLoading(true);
    setError(null);
    setResults([]);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const storeContext = selectedStores.length > 0 
        ? `Dê prioridade máxima para encontrar anúncios nestas lojas: ${selectedStores.join(', ')}.` 
        : '';
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Você é um buscador de ofertas em tempo real para construção civil no Brasil. 
        Sua missão absoluta é encontrar ANÚNCIOS REAIS, OFERTAS ATIVAS e PREÇOS VERDADEIROS para: "${finalQuery}".
        
        REGRAS DE OURO (NÃO NEGOCIÁVEIS):
        1. USE O GOOGLE SEARCH para validar cada preço e link.
        2. TUDO DEVE SER REAL. Não invente lojas, não invente preços, não invente links.
        3. LINKS ORIGINAIS: O campo "link" DEVE conter a URL ORIGINAL e REAL do produto. Aceite links oficiais como os do Mercado Livre (ex: meli.la ou mercadolivre.com.br), Leroy Merlin, Obramax, etc.
        4. FOQUE EM ANÚNCIOS DE HOJE. Priorize grandes varejistas e Lojas Oficiais.
        5. QUANTIDADE: Retorne o máximo de ofertas reais que encontrar (idealmente entre 12 a 20 resultados).
        6. ${storeContext}
        
        Formate como um array JSON de objetos:
        - material: Nome real do anúncio (ex: "Cimento Votoran CP II-E-32 Todas as Obras 50kg").
        - price: Preço real em Reais (ex: R$ 29,90).
        - store: Nome da loja física ou marketplace oficial.
        - link: URL ORIGINAL E CLICÁVEL (Ex: https://www.mercadolivre.com.br/p/MLB123456).
        - description: Detalhes da oferta (ex: "Oferta Relâmpago", "Vendido por Loja Oficial").
        
        SEJA PRECISO. O USUÁRIO PRECISA DE LINKS REAIS E OFICIAIS PARA COMPRAR AGORA.`,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json",
        },
      });

      const text = response.text;
      if (text) {
        const parsedResults = JSON.parse(text);
        const validResults = (Array.isArray(parsedResults) ? parsedResults : []).filter(item => {
          try {
            const url = new URL(item.link);
            return url.protocol === 'http:' || url.protocol === 'https:';
          } catch {
            return false;
          }
        });
        setResults(validResults);
        
        if (validResults.length === 0 && Array.isArray(parsedResults) && parsedResults.length > 0) {
          setError("As ofertas foram encontradas, mas os links oficiais parecem estar inacessíveis no momento. Tente pesquisar novamente.");
        }
      }
    } catch (err) {
      console.error("Erro na busca de preços:", err);
      setError("Não foi possível completar a busca. Tente novamente mais tarde.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-12">
      <header className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-50 text-brand-700 rounded-full text-sm font-bold animate-pulse">
          <Sparkles size={16} />
          Busca Inteligente de Preços
        </div>
        <h1 className="text-4xl font-bold text-slate-900 tracking-tight">Economize na sua Obra</h1>
        <p className="text-slate-500 max-w-2xl mx-auto">
          Utilizamos inteligência artificial e buscas em tempo real para encontrar as melhores ofertas em lojas confiáveis para você.
        </p>
      </header>

      <div className="glass-card p-8 rounded-3xl shadow-xl border border-white/20 space-y-6">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="O que você está procurando? (Ex: Cimento, Piso, Tinta...)"
              className="w-full pl-14 pr-4 py-5 bg-slate-50 border-2 border-slate-100 rounded-2xl text-lg focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all placeholder:text-slate-400"
            />
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" size={24} />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="relative">
              <div className="w-full pl-12 pr-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl text-sm min-h-[46px] flex flex-wrap gap-2 items-center">
                {selectedStores.length > 0 ? (
                  selectedStores.map(s => (
                    <span key={s} className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-md text-xs font-bold flex items-center gap-1">
                      {s}
                      <button type="button" onClick={() => toggleStore(s)} className="hover:text-emerald-900">×</button>
                    </span>
                  ))
                ) : (
                  <span className="text-slate-400">Lojas selecionadas</span>
                )}
              </div>
              <Store className="absolute left-4 top-3.5 text-slate-400" size={18} />
            </div>

            <div className="relative">
              <select
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value as SortOrder)}
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border-2 border-slate-100 rounded-xl text-sm focus:ring-4 focus:ring-brand-500/10 focus:border-brand-500 outline-none transition-all appearance-none"
              >
                <option value="asc">Menor Preço primeiro</option>
                <option value="desc">Maior Preço primeiro</option>
                <option value="none">Sem ordenação</option>
              </select>
              <ArrowUpDown className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            </div>
          </div>

          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-3">
              <div 
                onClick={() => setDirectLinkEnabled(!directLinkEnabled)}
                className={cn(
                  "w-12 h-6 rounded-full p-1 cursor-pointer transition-colors duration-200 ease-in-out",
                  directLinkEnabled ? "bg-brand-600" : "bg-slate-300"
                )}
              >
                <div className={cn(
                  "w-4 h-4 bg-white rounded-full shadow-sm transform transition-transform duration-200 ease-in-out",
                  directLinkEnabled ? "translate-x-6" : "translate-x-0"
                )} />
              </div>
              <span className="text-sm font-medium text-slate-700">Link direto para o produto</span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium italic">
              {directLinkEnabled ? "Clique no card para abrir a loja" : "Use o botão para abrir a loja"}
            </p>
          </div>

          <button
            type="submit"
            disabled={loading || (!query.trim() && selectedMaterials.length === 0)}
            className="w-full py-4 bg-brand-600 text-white rounded-2xl font-bold hover:bg-brand-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-brand-200"
          >
            {loading ? <Loader2 size={20} className="animate-spin" /> : <Search size={20} />}
            {loading ? 'Pesquisando...' : 'Buscar Melhores Ofertas'}
          </button>
        </form>

        <div className="space-y-4 pt-2">
          <div className="flex flex-wrap gap-3 items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Materiais:</span>
            {['Cimento CP II', 'Tinta Branca 18L', 'Porcelanato 60x60', 'Fio 2.5mm', 'Argamassa ACIII', 'Tijolo Baiano'].map((item) => (
              <button
                key={item}
                onClick={() => toggleMaterial(item)}
                className={cn(
                  "px-3 py-1 rounded-lg text-xs font-medium transition-colors border",
                  selectedMaterials.includes(item) 
                    ? "bg-brand-600 text-white border-brand-600" 
                    : "bg-slate-100 text-slate-600 border-transparent hover:bg-brand-50 hover:text-brand-700"
                )}
              >
                {item}
              </button>
            ))}
            {selectedMaterials.length > 0 && (
              <button 
                onClick={() => setSelectedMaterials([])}
                className="text-[10px] text-red-500 font-bold hover:underline ml-1"
              >
                Limpar
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-3 items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Lojas:</span>
            {['Leroy Merlin', 'Telhanorte', 'Mercado Livre', 'Obramax', 'Sodimac', 'C&C'].map((store) => (
              <button
                key={store}
                onClick={() => toggleStore(store)}
                className={cn(
                  "px-3 py-1 rounded-lg text-xs font-medium transition-colors border",
                  selectedStores.includes(store) 
                    ? "bg-emerald-600 text-white border-emerald-600" 
                    : "bg-slate-100 text-slate-600 border-transparent hover:bg-emerald-50 hover:text-emerald-700"
                )}
              >
                {store}
              </button>
            ))}
            {selectedStores.length > 0 && (
              <button 
                onClick={() => setSelectedStores([])}
                className="text-[10px] text-red-500 font-bold hover:underline ml-1"
              >
                Limpar
              </button>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-700">
          <AlertCircle size={20} />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {loading && (
        <div className="py-20 text-center space-y-4">
          <div className="relative inline-block">
            <div className="w-16 h-16 border-4 border-brand-100 border-t-brand-600 rounded-full animate-spin"></div>
            <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-brand-600 animate-pulse" size={24} />
          </div>
          <p className="text-slate-500 font-medium animate-pulse">Varrendo a web em busca de anúncios reais e ofertas ativas...</p>
        </div>
      )}

      {results.length > 0 && !loading && (
        <div className="flex items-center justify-between mb-2 px-2">
          <p className="text-sm font-bold text-slate-600">
            {results.length} ofertas reais encontradas
          </p>
          <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-full border border-emerald-100 uppercase tracking-tighter">
            <CheckCircle2 size={12} />
            Preços Verificados Hoje
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sortedResults.map((result, index) => {
          const isBestPrice = parsePrice(result.price) === minPrice && minPrice > 0;
          return (
            <div 
              key={index} 
              onClick={() => directLinkEnabled && result.link && window.open(result.link, '_blank')}
              className={cn(
                "glass-card p-6 rounded-3xl border transition-all group relative overflow-hidden flex flex-col",
                isBestPrice ? "border-emerald-400 bg-emerald-50/30 ring-2 ring-emerald-500/20" : "border-slate-100",
                directLinkEnabled ? "cursor-pointer hover:border-brand-400 hover:shadow-2xl" : "hover:border-brand-300 hover:shadow-xl"
              )}
            >
              {isBestPrice && (
                <div className="absolute -right-12 top-6 bg-emerald-500 text-white px-12 py-1 rotate-45 text-[10px] font-black uppercase tracking-widest shadow-lg z-10">
                  Melhor Preço
                </div>
              )}
              <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                {directLinkEnabled ? <ExternalLink className="text-brand-500" size={20} /> : <TrendingDown className="text-emerald-500" size={24} />}
              </div>
              
              <div className="space-y-4 flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Store size={14} className="text-brand-600" />
                      <span className="px-2 py-1 bg-brand-50 text-brand-700 rounded-lg text-[10px] font-bold uppercase tracking-wider inline-block border border-brand-100">
                        {result.store}
                      </span>
                      <span className="flex items-center gap-1 text-[9px] font-black text-emerald-600 uppercase tracking-tighter">
                        <div className="w-1 h-1 bg-emerald-500 rounded-full animate-ping" />
                        Anúncio Real
                      </span>
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-brand-600 transition-colors">
                      {result.material}
                    </h3>
                  </div>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className={cn(
                    "text-3xl font-black",
                    isBestPrice ? "text-emerald-600" : "text-slate-900"
                  )}>{result.price}</span>
                  <span className="text-xs text-slate-400 font-medium">Oferta verificada</span>
                </div>

                <p className="text-sm text-slate-500 leading-relaxed">
                  {result.description}
                </p>
              </div>

              <div className="pt-6 flex gap-3 mt-auto">
                <a
                  href={result.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-bold transition-colors",
                    isBestPrice ? "bg-emerald-600 hover:bg-emerald-700 text-white" : "bg-slate-900 hover:bg-slate-800 text-white"
                  )}
                >
                  <ShoppingCart size={18} />
                  Ir para Loja
                </a>
                <button className="p-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-brand-50 hover:text-brand-600 transition-colors">
                  <Info size={20} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {!loading && results.length === 0 && !error && query && (
        <div className="text-center py-20 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-sm">
            <Search className="text-slate-300" size={32} />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Nenhum resultado encontrado</h3>
          <p className="text-slate-500">Tente ajustar sua busca ou remover a loja de preferência.</p>
        </div>
      )}
    </div>
  );
}
