import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { AlertCircle, TrendingUp, Clock, CheckCircle2, Sparkles, Loader2, Tag, Plus, HardHat } from 'lucide-react';
import { Link } from 'react-router-dom';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useFirebase } from '../components/FirebaseProvider';
import { analyzeCosts } from '../services/geminiService';
import Markdown from 'react-markdown';

export default function Dashboard() {
  const [projects, setProjects] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [aiInsight, setAiInsight] = React.useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = React.useState(false);
  const { user } = useFirebase();

  React.useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'projects'), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projectsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProjects(projectsData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const stats = {
    active: projects.filter(p => p.status !== 'Concluído').length,
    delayed: projects.filter(p => p.status === 'Atrasado').length,
    completed: projects.filter(p => p.status === 'Concluído').length,
    totalBudget: projects.reduce((acc, p) => acc + (p.budget || 0), 0)
  };

  const chartData = projects.slice(0, 6).map(p => ({
    name: p.name.substring(0, 10),
    custo: p.spent || 0,
    orcado: p.budget || 0
  }));

  const handleGetAiInsight = async () => {
    if (projects.length === 0) return;
    setIsAnalyzing(true);
    try {
      // Analyze the general state of projects
      const summary = projects.map(p => ({ name: p.name, status: p.status, progress: p.progress, budget: p.budget, spent: p.spent }));
      const insight = await analyzeCosts(summary);
      setAiInsight(insight || "Não foi possível gerar insights.");
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="animate-spin text-brand-600" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Visão geral de todas as suas obras.</p>
        </div>
        <button 
          onClick={handleGetAiInsight}
          disabled={isAnalyzing || projects.length === 0}
          className="flex items-center gap-2 px-4 py-2 bg-brand-50 text-brand-600 rounded-xl font-medium hover:bg-brand-100 transition-colors disabled:opacity-50"
        >
          {isAnalyzing ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
          Insights IA
        </button>
      </header>

      {aiInsight && (
        <div className="glass-card p-6 rounded-2xl bg-brand-50/50 border-brand-100">
          <div className="flex items-center gap-2 text-brand-600 font-bold mb-3">
            <Sparkles size={20} />
            <h4>Insights Estratégicos</h4>
          </div>
          <div className="text-sm text-slate-700 prose prose-slate max-w-none">
            <Markdown>{aiInsight}</Markdown>
          </div>
          <button 
            onClick={() => setAiInsight(null)}
            className="mt-4 text-xs text-slate-400 hover:text-slate-600 font-medium"
          >
            Fechar Insights
          </button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Obras Ativas', value: stats.active, icon: TrendingUp, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Em Atraso', value: stats.delayed, icon: AlertCircle, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Concluídas', value: stats.completed, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Orçamento Total', value: `R$ ${(stats.totalBudget / 1000).toFixed(1)}k`, icon: Clock, color: 'text-slate-600', bg: 'bg-slate-50' },
        ].map((stat) => (
          <div key={stat.label} className="glass-card p-6 rounded-2xl">
            <div className={stat.bg + " w-10 h-10 rounded-xl flex items-center justify-center mb-4"}>
              <stat.icon size={20} className={stat.color} />
            </div>
            <p className="text-sm font-medium text-slate-500">{stat.label}</p>
            <p className="text-2xl font-bold text-slate-900 mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Link to="/obras" className="glass-card p-6 rounded-2xl flex items-center gap-4 hover:border-brand-300 transition-all group">
          <div className="w-12 h-12 bg-brand-50 text-brand-600 rounded-xl flex items-center justify-center group-hover:bg-brand-600 group-hover:text-white transition-colors">
            <Plus size={24} />
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Nova Obra</h4>
            <p className="text-xs text-slate-500">Cadastre um novo projeto</p>
          </div>
        </Link>
        <Link to="/cotacoes" className="glass-card p-6 rounded-2xl flex items-center gap-4 hover:border-emerald-300 transition-all group">
          <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center group-hover:bg-emerald-600 group-hover:text-white transition-colors">
            <Tag size={24} />
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Buscar Preços</h4>
            <p className="text-xs text-slate-500">Encontre as melhores ofertas</p>
          </div>
        </Link>
        <Link to="/equipe" className="glass-card p-6 rounded-2xl flex items-center gap-4 hover:border-blue-300 transition-all group">
          <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <Plus size={24} />
          </div>
          <div>
            <h4 className="font-bold text-slate-900">Gerir Equipe</h4>
            <p className="text-xs text-slate-500">Controle seus colaboradores</p>
          </div>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cost Chart */}
        <div className="glass-card p-6 rounded-2xl">
          <h3 className="font-bold text-lg mb-6">Custos vs Orçado (Principais Obras)</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="custo" fill="#10b981" radius={[4, 4, 0, 0]} name="Custo Real" />
                <Bar dataKey="orcado" fill="#e2e8f0" radius={[4, 4, 0, 0]} name="Orçado" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Recent Projects Table */}
        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-bold text-lg">Obras Recentes</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider font-bold">
                  <th className="px-6 py-4">Obra</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Progresso</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {projects.slice(0, 5).map((project) => (
                  <tr key={project.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-900">{project.name}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-full text-xs font-bold",
                        project.status === 'Em andamento' ? "bg-blue-50 text-blue-700" : 
                        project.status === 'Atrasado' ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"
                      )}>
                        {project.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-24 bg-slate-100 rounded-full h-1.5">
                          <div className="bg-brand-500 h-1.5 rounded-full" style={{ width: `${project.progress}%` }}></div>
                        </div>
                        <span className="text-xs font-bold text-slate-600">{project.progress}%</span>
                      </div>
                    </td>
                  </tr>
                ))}
                {projects.length === 0 && (
                  <tr>
                    <td colSpan={3} className="px-6 py-8 text-center text-slate-500">Nenhuma obra encontrada.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
