import React from 'react';
import { Link } from 'react-router-dom';
import { Plus, Sparkles, Loader2 } from 'lucide-react';
import Modal from '../components/Modal';
import ProjectForm from '../components/ProjectForm';
import { collection, addDoc, onSnapshot, query, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useFirebase } from '../components/FirebaseProvider';
import { suggestBudget } from '../services/geminiService';
import Markdown from 'react-markdown';

const Projects = () => {
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const [projects, setProjects] = React.useState<any[]>([]);
  const [aiSuggestion, setAiSuggestion] = React.useState<string | null>(null);
  const [isSuggesting, setIsSuggesting] = React.useState(false);
  const { user } = useFirebase();

  React.useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'projects'), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const projectsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProjects(projectsData);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'projects');
    });

    return () => unsubscribe();
  }, [user]);

  const handleAddProject = async (data: any) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'projects'), {
        ...data,
        ownerId: user.uid,
        progress: 0,
        status: 'Planejamento'
      });
      setIsModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'projects');
    }
  };

  const handleSuggestBudget = async () => {
    if (projects.length === 0) return;
    setIsSuggesting(true);
    try {
      const suggestion = await suggestBudget(projects);
      setAiSuggestion(suggestion || "Não foi possível gerar a sugestão.");
    } catch (error) {
      console.error(error);
    } finally {
      setIsSuggesting(false);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Obras</h1>
          <p className="text-slate-500">Gerencie seus projetos de construção.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={handleSuggestBudget}
            disabled={isSuggesting || projects.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-brand-50 text-brand-600 rounded-xl font-medium hover:bg-brand-100 transition-colors disabled:opacity-50"
          >
            {isSuggesting ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
            Sugerir Orçamento
          </button>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-brand-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-brand-700 transition-colors flex items-center gap-2"
          >
            <Plus size={18} />
            Nova Obra
          </button>
        </div>
      </header>

      {aiSuggestion && (
        <div className="glass-card p-6 rounded-2xl bg-brand-50/50 border-brand-100">
          <div className="flex items-center gap-2 text-brand-600 font-bold mb-3">
            <Sparkles size={20} />
            <h4>Sugestão de Orçamento por IA</h4>
          </div>
          <div className="text-sm text-slate-700 prose prose-slate max-w-none">
            <Markdown>{aiSuggestion}</Markdown>
          </div>
          <button 
            onClick={() => setAiSuggestion(null)}
            className="mt-4 text-xs text-slate-400 hover:text-slate-600 font-medium"
          >
            Fechar Sugestão
          </button>
        </div>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map(project => (
          <Link key={project.id} to={`/obras/${project.id}`} className="glass-card overflow-hidden rounded-2xl border-l-4 border-brand-500 hover:shadow-md transition-all flex flex-col">
            {project.imageUrl && (
              <div className="w-full h-32 overflow-hidden">
                <img 
                  src={project.imageUrl} 
                  alt={project.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}
            <div className="p-6">
              <h3 className="font-bold text-lg">{project.name}</h3>
              <p className="text-sm text-slate-500">Endereço: {project.address || 'Não informado'}</p>
              <div className="mt-4">
                <div className="flex justify-between text-xs mb-1">
                  <span>Progresso</span>
                  <span>{project.progress}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-2">
                  <div className="bg-brand-500 h-2 rounded-full" style={{ width: `${project.progress}%` }}></div>
                </div>
              </div>
            </div>
          </Link>
        ))}
        {projects.length === 0 && (
          <div className="col-span-full text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhuma obra cadastrada ainda.</p>
          </div>
        )}
      </div>

      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title="Cadastrar Nova Obra"
      >
        <ProjectForm 
          onSubmit={handleAddProject} 
          onCancel={() => setIsModalOpen(false)} 
        />
      </Modal>
    </div>
  );
};

export default Projects;
