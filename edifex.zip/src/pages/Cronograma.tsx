import React, { useState } from 'react';
import { Calendar as CalendarIcon, List, AlertTriangle } from 'lucide-react';
import InteractiveCalendar from '../components/InteractiveCalendar';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: any[]) {
  return twMerge(clsx(inputs));
}

export default function Cronograma() {
  const [view, setView] = useState<'calendar' | 'timeline'>('calendar');
  const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  
  const stages = [
    { name: 'Fundação', start: 0, duration: 1.5, status: 'Concluída' },
    { name: 'Estrutura', start: 1.5, duration: 2.5, status: 'Em andamento' },
    { name: 'Alvenaria', start: 3, duration: 2, status: 'Em andamento' },
    { name: 'Elétrica', start: 5, duration: 1.5, status: 'Planejada' },
    { name: 'Hidráulica', start: 5.5, duration: 1.5, status: 'Planejada' },
    { name: 'Acabamento', start: 7, duration: 3, status: 'Planejada' },
  ];

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Cronograma</h1>
          <p className="text-slate-500">Acompanhe o planejamento temporal das suas obras.</p>
        </div>
        
        <div className="flex bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
          <button 
            onClick={() => setView('calendar')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all",
              view === 'calendar' ? "bg-brand-600 text-white shadow-md" : "text-slate-600 hover:bg-slate-50"
            )}
          >
            <CalendarIcon size={18} />
            Calendário
          </button>
          <button 
            onClick={() => setView('timeline')}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-all",
              view === 'timeline' ? "bg-brand-600 text-white shadow-md" : "text-slate-600 hover:bg-slate-50"
            )}
          >
            <List size={18} />
            Linha do Tempo
          </button>
        </div>
      </header>

      {view === 'calendar' ? (
        <InteractiveCalendar />
      ) : (
        <div className="glass-card p-6 rounded-2xl overflow-hidden">
          <div className="flex items-center gap-2 mb-8 p-3 bg-amber-50 text-amber-700 rounded-xl text-sm border border-amber-100">
            <AlertTriangle size={18} />
            <span className="font-medium">Atenção: A etapa de "Estrutura" está com 5 dias de atraso em relação ao planejado.</span>
          </div>

          <div className="overflow-x-auto">
            <div className="min-w-[800px]">
              {/* Timeline Header */}
              <div className="flex border-b border-slate-100 mb-4">
                <div className="w-48 shrink-0 font-bold text-xs text-slate-400 uppercase tracking-wider pb-2">Etapa</div>
                <div className="flex-1 grid grid-cols-12 gap-0">
                  {months.map(m => (
                    <div key={m} className="text-center font-bold text-xs text-slate-400 uppercase tracking-wider pb-2 border-l border-slate-50">
                      {m}
                    </div>
                  ))}
                </div>
              </div>

              {/* Timeline Rows */}
              <div className="space-y-4">
                {stages.map((stage) => (
                  <div key={stage.name} className="flex items-center group">
                    <div className="w-48 shrink-0">
                      <p className="font-bold text-slate-900 text-sm">{stage.name}</p>
                      <p className="text-[10px] text-slate-500 uppercase font-bold">{stage.status}</p>
                    </div>
                    <div className="flex-1 relative h-8 bg-slate-50/50 rounded-lg">
                      <div 
                        className={cn(
                          "absolute h-full rounded-lg transition-all duration-500 flex items-center px-3 text-[10px] font-bold text-white",
                          stage.status === 'Concluída' ? "bg-emerald-500" : 
                          stage.status === 'Em andamento' ? "bg-brand-500 shadow-lg shadow-brand-100" : "bg-slate-200"
                        )}
                        style={{ 
                          left: `${(stage.start / 12) * 100}%`, 
                          width: `${(stage.duration / 12) * 100}%` 
                        }}
                      >
                        {stage.status === 'Em andamento' && "85%"}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
