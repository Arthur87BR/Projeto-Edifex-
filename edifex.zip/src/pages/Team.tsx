import React, { useState, useEffect } from 'react';
import { Plus, Search, Phone, Mail, MoreVertical, Loader2, X } from 'lucide-react';
import { collection, addDoc, onSnapshot, query, where, deleteDoc, doc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { useFirebase } from '../components/FirebaseProvider';
import Modal from '../components/Modal';

import ImageUpload from '../components/ImageUpload';

const ROLES = [
  'Engenheiro(a)',
  'Arquiteto(a)',
  'Mestre de Obras',
  'Pedreiro',
  'Servente',
  'Eletricista',
  'Encanador',
  'Pintor',
  'Gesseiro',
  'Carpinteiro',
  'Armador',
  'Outro'
];

export default function Team() {
  const { user } = useFirebase();
  const [members, setMembers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: ROLES[0],
    rate: '',
    status: 'Ativo',
    photoUrl: ''
  });

  useEffect(() => {
    if (!user) return;

    const q = query(collection(db, 'team'), where('ownerId', '==', user.uid));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const teamData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMembers(teamData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'team');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    try {
      await addDoc(collection(db, 'team'), {
        ...formData,
        ownerId: user.uid
      });
      setIsModalOpen(false);
      setFormData({ name: '', email: '', role: ROLES[0], rate: '', status: 'Ativo', photoUrl: '' });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'team');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteMember = async (id: string) => {
    if (!window.confirm('Tem certeza que deseja remover este membro?')) return;
    try {
      await deleteDoc(doc(db, 'team', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, 'team');
    }
  };

  const filteredMembers = members.filter(m => 
    m.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    m.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="animate-spin text-brand-600" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Equipe</h1>
          <p className="text-slate-500">Gerencie seus trabalhadores e prestadores de serviço.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-brand-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-brand-700 transition-colors flex items-center gap-2"
        >
          <Plus size={20} />
          Novo Membro
        </button>
      </header>

      <div className="flex gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input
            type="text"
            placeholder="Buscar por nome ou cargo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map((member) => (
          <div key={member.id} className="glass-card p-6 rounded-2xl relative group">
            <button 
              onClick={() => handleDeleteMember(member.id)}
              className="absolute top-6 right-6 text-slate-400 hover:text-red-600 transition-colors"
            >
              <X size={20} />
            </button>
            <div className="flex items-center gap-4 mb-4">
              {member.photoUrl ? (
                <img 
                  src={member.photoUrl} 
                  alt={member.name} 
                  className="w-12 h-12 rounded-full object-cover border-2 border-brand-100"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 font-bold text-lg">
                  {member.name.charAt(0)}
                </div>
              )}
              <div>
                <h3 className="font-bold text-slate-900">{member.name}</h3>
                <p className="text-sm text-slate-500">{member.role}</p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">E-mail</span>
                <span className="font-medium truncate max-w-[150px]">{member.email}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Valor Diária</span>
                <span className="font-medium">{member.rate || 'N/A'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Status</span>
                <span className={member.status === 'Ativo' ? 'text-emerald-600 font-medium' : 'text-slate-500 font-medium'}>
                  {member.status}
                </span>
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <a href={`mailto:${member.email}`} className="flex-1 flex items-center justify-center gap-2 py-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors">
                <Mail size={16} />
                <span className="text-xs font-bold">E-mail</span>
              </a>
            </div>
          </div>
        ))}
        {filteredMembers.length === 0 && (
          <div className="col-span-full text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
            <p className="text-slate-500">Nenhum membro encontrado.</p>
          </div>
        )}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Novo Membro da Equipe">
        <form onSubmit={handleAddMember} className="space-y-4">
          <ImageUpload 
            onUploadComplete={(url) => setFormData({ ...formData, photoUrl: url })}
            label="Foto do Membro"
            folder="team"
          />
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Nome Completo</label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
              placeholder="Ex: João Silva"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">E-mail</label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
              placeholder="joao@email.com"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Cargo</label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value })}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none bg-white"
            >
              {ROLES.map(role => (
                <option key={role} value={role}>{role}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1">Valor Diária (Opcional)</label>
            <input
              type="text"
              value={formData.rate}
              onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
              className="w-full px-4 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 outline-none"
              placeholder="Ex: R$ 200"
            />
          </div>
          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="flex-1 px-4 py-2 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 px-4 py-2 bg-brand-600 text-white rounded-xl font-bold hover:bg-brand-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {submitting ? <Loader2 size={18} className="animate-spin" /> : 'Salvar'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
