import React, { useState } from 'react';
import { User, Bell, Shield, CreditCard, Building, HelpCircle, LogOut, Loader2 } from 'lucide-react';
import { useFirebase } from '../components/FirebaseProvider';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import ImageUpload from '../components/ImageUpload';

export default function Settings() {
  const { userProfile, logout, user, refreshProfile } = useFirebase();
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    displayName: userProfile?.displayName || '',
    role: userProfile?.role || '',
    company: userProfile?.company || '',
    photoUrl: userProfile?.photoUrl || ''
  });

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), formData);
      await refreshProfile();
      alert('Perfil atualizado com sucesso!');
    } catch (error) {
      console.error("Error updating profile:", error);
      alert('Erro ao atualizar perfil.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Configurações</h1>
        <p className="text-slate-500">Gerencie sua conta e preferências da plataforma.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sidebar Settings */}
        <div className="lg:col-span-1 space-y-2">
          <div className="p-4 bg-white rounded-2xl border border-slate-200 mb-4 flex flex-col items-center text-center">
            <div className="w-20 h-20 rounded-full overflow-hidden bg-brand-100 mb-3 border-2 border-brand-500">
              {userProfile?.photoUrl ? (
                <img src={userProfile.photoUrl} alt="Avatar" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-brand-700 font-bold text-2xl">
                  {userProfile?.displayName?.charAt(0) || 'U'}
                </div>
              )}
            </div>
            <h4 className="font-bold text-slate-900">{userProfile?.displayName}</h4>
            <p className="text-xs text-slate-500">{userProfile?.role}</p>
          </div>
          
          {[
            { icon: User, label: 'Perfil', active: true },
            { icon: Building, label: 'Empresa', active: false },
            { icon: Bell, label: 'Notificações', active: false },
            { icon: Shield, label: 'Segurança', active: false },
            { icon: CreditCard, label: 'Assinatura', active: false },
            { icon: HelpCircle, label: 'Ajuda e Suporte', active: false },
          ].map((item) => (
            <button
              key={item.label}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors",
                item.active ? "bg-brand-50 text-brand-600" : "text-slate-600 hover:bg-slate-50"
              )}
            >
              <item.icon size={20} />
              {item.label}
            </button>
          ))}
          
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-red-600 hover:bg-red-50 transition-colors mt-4"
          >
            <LogOut size={20} />
            Sair da Conta
          </button>
        </div>

        {/* Main Content Settings */}
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-card p-6 rounded-2xl">
            <h3 className="font-bold text-lg mb-6">Informações Pessoais</h3>
            <div className="space-y-6">
              <ImageUpload 
                onUploadComplete={(url) => setFormData({ ...formData, photoUrl: url })}
                currentImageUrl={formData.photoUrl}
                label="Sua Foto de Perfil"
                folder="avatars"
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Nome Completo</label>
                  <input 
                    type="text" 
                    value={formData.displayName}
                    onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">E-mail</label>
                  <input 
                    type="email" 
                    readOnly
                    value={userProfile?.email || ''}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none opacity-60 cursor-not-allowed"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Cargo</label>
                <input 
                  type="text" 
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Empresa</label>
                <input 
                  type="text" 
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500"
                />
              </div>
              <div className="pt-4">
                <button 
                  onClick={handleSave}
                  disabled={saving}
                  className="px-6 py-2 bg-brand-600 text-white rounded-xl font-medium hover:bg-brand-700 transition-colors flex items-center gap-2 disabled:opacity-50"
                >
                  {saving && <Loader2 size={18} className="animate-spin" />}
                  Salvar Alterações
                </button>
              </div>
            </div>
          </div>

          <div className="glass-card p-6 rounded-2xl border-l-4 border-amber-500">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-50 flex items-center justify-center shrink-0">
                <CreditCard className="text-amber-600" size={24} />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Plano Profissional</h4>
                <p className="text-sm text-slate-500 mb-4">Sua assinatura está ativa.</p>
                <button className="text-sm font-bold text-brand-600 hover:underline">
                  Gerenciar Assinatura
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
