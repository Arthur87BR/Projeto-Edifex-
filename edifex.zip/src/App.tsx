/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import React from 'react';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import ProjectDetail from './pages/ProjectDetail';
import Team from './pages/Team';
import Cronograma from './pages/Cronograma';
import Settings from './pages/Settings';
import PriceSearch from './pages/PriceSearch';
import Modal from './components/Modal';
import ProjectForm from './components/ProjectForm';
import { FirebaseProvider, useFirebase } from './components/FirebaseProvider';
import Login from './pages/Login';
import Onboarding from './pages/Onboarding';
import ErrorBoundary from './components/ErrorBoundary';
import { collection, addDoc, onSnapshot, query, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';

import Projects from './pages/Projects';

const AppContent = () => {
  const { user, userProfile, loading } = useFirebase();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-brand-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/obras" element={<Projects />} />
        <Route path="/obras/:id" element={<ProjectDetail />} />
        <Route path="/equipe" element={<Team />} />
        <Route path="/cronograma" element={<Cronograma />} />
        <Route path="/cotacoes" element={<PriceSearch />} />
        <Route path="/configuracoes" element={<Settings />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <FirebaseProvider>
        <Router>
          <AppContent />
        </Router>
      </FirebaseProvider>
    </ErrorBoundary>
  );
}







